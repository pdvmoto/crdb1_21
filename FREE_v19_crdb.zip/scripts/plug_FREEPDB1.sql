SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/FREE/scripts/plugDatabase.log append
spool /opt/oracle/admin/FREE/scripts/plugDatabase.log append
CREATE PLUGGABLE DATABASE "FREEPDB1" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  file_name_convert=NONE  STORAGE ( MAXSIZE UNLIMITED MAX_SHARED_TEMP_SIZE UNLIMITED);
select name from v$containers where upper(name) = 'FREEPDB1';
alter pluggable database "FREEPDB1" open;
alter system register;
ALTER SESSION SET CONTAINER = "FREEPDB1";
