set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /opt/oracle/product/21c/dbhome_1/bin/orapwd file=/opt/oracle/dbs/orapwFREE force=y format=12
@/opt/oracle/admin/FREE/scripts/CreateDB.sql
@/opt/oracle/admin/FREE/scripts/CreateDBFiles.sql
@/opt/oracle/admin/FREE/scripts/CreateDBCatalog.sql
@/opt/oracle/admin/FREE/scripts/JServer.sql
@/opt/oracle/admin/FREE/scripts/context.sql
@/opt/oracle/admin/FREE/scripts/ordinst.sql
@/opt/oracle/admin/FREE/scripts/interMedia.sql
@/opt/oracle/admin/FREE/scripts/cwmlite.sql
@/opt/oracle/admin/FREE/scripts/spatial.sql
@/opt/oracle/admin/FREE/scripts/CreateClustDBViews.sql
@/opt/oracle/admin/FREE/scripts/lockAccount.sql
@/opt/oracle/admin/FREE/scripts/postDBCreation.sql
@/opt/oracle/admin/FREE/scripts/PDBCreation.sql
@/opt/oracle/admin/FREE/scripts/plug_FREEPDB1.sql
@/opt/oracle/admin/FREE/scripts/postPDBCreation_FREEPDB1.sql
@/opt/oracle/admin/FREE/scripts/plug_FREEPDB2.sql
@/opt/oracle/admin/FREE/scripts/postPDBCreation_FREEPDB2.sql
