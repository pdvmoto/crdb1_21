SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/FREE/scripts/plugDatabase1R.log append
spool /opt/oracle/admin/FREE/scripts/plugDatabase1R.log append
CREATE PLUGGABLE DATABASE "FREEPDB2" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  file_name_convert=NONE  STORAGE ( MAXSIZE UNLIMITED MAX_SHARED_TEMP_SIZE UNLIMITED);
select name from v$containers where upper(name) = 'FREEPDB2';
alter pluggable database "FREEPDB2" open;
alter system register;
ALTER SESSION SET CONTAINER = "FREEPDB2";
