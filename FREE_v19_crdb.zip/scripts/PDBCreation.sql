SET VERIFY OFF
set echo on
spool /opt/oracle/admin/FREE/scripts/PDBCreation.log append
