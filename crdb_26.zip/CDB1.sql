set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /opt/oracle/oradata/orainst/bin/orapwd file=/opt/oracle/oradata/orainst/dbs/orapwCDB1 force=y format=12
@/opt/oracle/admin/CDB1/scripts/CreateDB.sql
@/opt/oracle/admin/CDB1/scripts/CreateDBFiles.sql
@/opt/oracle/admin/CDB1/scripts/CreateDBCatalog.sql
@/opt/oracle/admin/CDB1/scripts/JServer.sql
@/opt/oracle/admin/CDB1/scripts/context.sql
@/opt/oracle/admin/CDB1/scripts/cwmlite.sql
@/opt/oracle/admin/CDB1/scripts/spatial.sql
@/opt/oracle/admin/CDB1/scripts/CreateClustDBViews.sql
@/opt/oracle/admin/CDB1/scripts/lockAccount.sql
@/opt/oracle/admin/CDB1/scripts/postDBCreation.sql
@/opt/oracle/admin/CDB1/scripts/PDBCreation.sql
@/opt/oracle/admin/CDB1/scripts/plug_CDB1pdb1.sql
@/opt/oracle/admin/CDB1/scripts/postPDBCreation_CDB1pdb1.sql
