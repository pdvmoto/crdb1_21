SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/CreateClustDBViews.log append
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  catclust   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/rdbms/admin/catclust.sql;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  catfinal   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/rdbms/admin/catfinal.sql;
spool off
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/postDBCreation.log append
