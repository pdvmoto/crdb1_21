SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/spatial.log append
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  mdinst  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/md/admin/mdinst.sql;
spool off
