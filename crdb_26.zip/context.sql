SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/context.log append
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  catctx  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/oradata/orainst/ctx/admin/catctx.sql;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  dr0defin  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/oradata/orainst/ctx/admin/defaults/dr0defin.sql;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  dbmsxdbt  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/rdbms/admin/dbmsxdbt.sql;
spool off
