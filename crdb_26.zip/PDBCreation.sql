SET VERIFY OFF
set echo on
spool /opt/oracle/admin/CDB1/scripts/PDBCreation.log append
