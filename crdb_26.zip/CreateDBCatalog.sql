SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/CreateDBCatalog.log append
alter session set "_oracle_script"=true;
alter pluggable database pdb$seed close;
alter pluggable database pdb$seed open;
host /opt/oracle/oradata/orainst/perl/bin/perl /opt/oracle/oradata/orainst/rdbms/admin/catctl.pl  -u "SYS"/"&&sysPassword" -n 4 -icatpcat -c 'CDB$ROOT PDB$SEED' -a  -d /opt/oracle/oradata/orainst/rdbms/admin -l /opt/oracle/admin/CDB1/scripts rdbms/admin/catpcat.sql;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  owminst   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/rdbms/admin/owminst.plb;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  pupbld  -u  SYSTEM/&&systemPassword   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/sqlplus/admin/pupbld.sql;
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  pupdel  -u  SYS/&&sysPassword   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/sqlplus/admin/pupdel.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/CDB1/scripts/sqlPlusHelp.log append
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  hlpbld  -u  SYS/&&sysPassword   -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/oradata/orainst/sqlplus/admin/help/hlpbld.sql;
spool off
spool off
