#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /opt/oracle
mkdir -p /opt/oracle/admin/CDB1/dpdump
mkdir -p /opt/oracle/admin/CDB1/pfile
mkdir -p /opt/oracle/admin/CDB1/scripts
mkdir -p /opt/oracle/audit
mkdir -p /opt/oracle/oradata
mkdir -p /opt/oracle/oradata/orainst/dbs
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=CDB1; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/perl/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: CDB1:/opt/oracle/oradata/orainst:Y
/opt/oracle/oradata/orainst/bin/sqlplus /nolog @/opt/oracle/admin/CDB1/scripts/CDB1.sql
