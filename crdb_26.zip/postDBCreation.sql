SET VERIFY OFF
spool /opt/oracle/admin/CDB1/scripts/postDBCreation.log append
host /opt/oracle/oradata/orainst/OPatch/datapatch -skip_upgrade_check -db CDB1;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='/opt/oracle/oradata/orainst/dbs/spfileCDB1.ora' FROM pfile='/opt/oracle/admin/CDB1/scripts/init.ora';
connect "SYS"/"&&sysPassword" as SYSDBA
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  utlrp   -U  "SYS"/"&&sysPassword"  /opt/oracle/oradata/orainst/rdbms/admin/utlrp.sql;
select comp_id, status from dba_registry;
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
spool off
select instance from v$thread where instance like 'UNNAMED_INSTANCE%';
