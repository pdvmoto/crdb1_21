SET VERIFY OFF
set echo on
spool /opt/oracle/admin/CDB1/scripts/cwmlite.log append
connect "SYS"/"&&sysPassword" as SYSDBA
host /opt/oracle/oradata/orainst/perl/bin/perl  /opt/oracle/oradata/orainst/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/CDB1/scripts  -v   -b  olap  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/oradata/orainst/olap/admin/olap.sql;
spool off
