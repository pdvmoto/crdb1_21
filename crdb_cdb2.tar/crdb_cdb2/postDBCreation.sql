SET VERIFY OFF
spool /opt/oracle/admin/cdb2/scripts/postDBCreation.log append
host /opt/oracle/product/26ai/dbhome_1/OPatch/datapatch -skip_upgrade_check -db cdb2;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='/opt/oracle/product/26ai/dbhome_1/dbs/spfilecdb2.ora' FROM pfile='/opt/oracle/admin/cdb2/scripts/init.ora';
connect "SYS"/"&&sysPassword" as SYSDBA
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/cdb2/scripts  -v   -b  utlrp   -U  "SYS"/"&&sysPassword"  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/utlrp.sql;
select comp_id, status from dba_registry;
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
spool off
select instance from v$thread where instance like 'UNNAMED_INSTANCE%';
