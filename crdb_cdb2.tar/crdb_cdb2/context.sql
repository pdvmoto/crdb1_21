SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/cdb2/scripts/context.log append
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/cdb2/scripts  -v   -b  catctx  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/product/26ai/dbhome_1/ctx/admin/catctx.sql;
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/cdb2/scripts  -v   -b  dr0defin  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/product/26ai/dbhome_1/ctx/admin/defaults/dr0defin.sql;
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/cdb2/scripts  -v   -b  dbmsxdbt  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/dbmsxdbt.sql;
spool off
